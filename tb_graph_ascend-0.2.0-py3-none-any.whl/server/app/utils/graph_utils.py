# Copyright (c) 2025, Huawei Technologies.
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import json
import os
from tensorboard.util import tb_logging
from .global_state import get_global_value, set_global_value

logger = tb_logging.get_logger()
MAX_FILE_SIZE = 1000 * 1024 * 1024  # 最大文件大小限制为1000MB


class GraphUtils:

    # 检查是否使用缓存
    @staticmethod
    def check_jsondata(tag):
        _current_tag = get_global_value('current_tag')
        if _current_tag == tag:
            return get_global_value('current_file_data')
        else:
            return None

    # 读取json文件
    @staticmethod
    def get_jsondata(run, tag):
        json_data = None
        error_message = None
        logdir = get_global_value('logdir')
        if run is None or tag is None:
            error_message = 'The query parameters "run" and "tag" are required'
            return json_data, error_message
        run_dir = os.path.join(logdir, run)
        run_dir = os.path.normpath(run_dir)  # 标准化路径
        file_path = GraphUtils._load_json_file(run_dir, tag)
        if not file_path:
            error_message = f'vis file for tag "{tag}" not found in run "{run}"'
            return json_data, error_message
        json_data = GraphUtils._read_json_file(file_path)
        set_global_value('current_file_data', json_data)
        set_global_value('current_tag', tag)
        if json_data is None:
            error_message = f'Error reading vis file for tag "{tag}" in run "{run}"'
        return json_data, error_message

    @staticmethod
    def _load_json_file(run_dir, tag):
        """Load a single .vis file from a given directory based on the tag."""
        file_path = os.path.join(run_dir, f"{tag}.vis")
        file_path = os.path.normpath(file_path)  # 标准化路径
        if os.path.exists(file_path):
            # 校验文件的读权限
            if not os.access(file_path, os.R_OK):
                logger.error(f'Error: No read permission for file "{file_path}"')
                return None
            # 校验文件大小
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                logger.error(f'Error: File "{file_path}" exceeds the size limit of {MAX_FILE_SIZE // (1024 * 1024)}MB')
                return None
            set_global_value('current_file_path', file_path)
            return file_path
        else:
            logger.error(f'Error: File "{file_path}" does not exist.')
        return None

    @staticmethod
    def _read_json_file(file_path):
        """Read and parse a JSON file from disk."""
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    # 尝试解析 JSON 文件
                    return json.load(f)
            except json.JSONDecodeError:
                logger.error(f'Error: File "{file_path}" is not a valid JSON file!')
            except Exception as e:
                logger.error(f'Unexpected error while reading file "{file_path}": {e}')
        else:
            logger.error(f'Error: File "{file_path}" is not accessible.')
        return None
