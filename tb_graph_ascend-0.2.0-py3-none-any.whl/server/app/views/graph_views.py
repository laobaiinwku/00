# Copyright (c) 2025, Huawei Technologies.
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import json
from werkzeug import wrappers, Response, exceptions
from tensorboard.backend import http_util
from ..controllers.graph_controller import GraphController


class GraphView:

    # 获取当前节点对应节点的信息看板数据
    @wrappers.Request.application
    def get_node_info(request):
        node_info = json.loads(request.args.get("nodeInfo"))
        meta_data = json.loads(request.args.get("metaData"))
        node_detail = GraphController.get_node_info(node_info, meta_data)
        return http_util.Respond(request, node_detail, "application/json")
