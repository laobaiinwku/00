# Copyright (c) 2025, Huawei Technologies.
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

from ..utils.graph_utils import GraphUtils


class GraphController:

    def get_node_info(node_info, meta_data):
        run = meta_data.get('run')
        tag = meta_data.get('tag')
        nodeType = node_info.get('nodeType')
        nodeName = node_info.get('nodeName')
        graph_data = GraphUtils.check_jsondata(tag)
        if graph_data is None:
            graph_data, error_message = GraphUtils.get_jsondata(run, tag)
            if error_message is not None:
                return {'success': False, 'error': error_message}
        node_details = graph_data.get(nodeType, {}).get('node', {}).get(nodeName)
        return {'success': True, 'data': node_details}
