/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
export async function render() {
  document.location.href = 'index.html';
}
